<?php
// URL helper shim
